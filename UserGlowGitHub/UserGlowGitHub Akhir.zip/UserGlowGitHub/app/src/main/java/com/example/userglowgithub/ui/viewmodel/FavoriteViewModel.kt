package com.example.userglowgithub.ui.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.userglowgithub.ui.Result.FavoriteRepository
import com.example.userglowgithub.ui.response.GitHubUserDetailResponse
import com.example.userglowgithub.ui.response.GlowFollowersResponse

class FavoriteViewModel(private val repository: FavoriteRepository) : ViewModel() {

    private val _user = MutableLiveData<GitHubUserDetailResponse>()
    val user: LiveData<GitHubUserDetailResponse> = _user

    fun getFavoriteUser() = repository.getAllFavorites()

    companion object {
        private const val TAG = "FavoriteViewModel"
    }

}
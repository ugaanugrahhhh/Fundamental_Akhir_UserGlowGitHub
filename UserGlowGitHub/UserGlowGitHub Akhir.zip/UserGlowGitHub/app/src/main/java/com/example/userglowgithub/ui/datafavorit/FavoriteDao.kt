package com.example.userglowgithub.ui.datafavorit

import androidx.lifecycle.LiveData
import androidx.room.*

@Dao
interface FavoriteDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun masukkanDataFavorit(favorite: Favorite)

    @Update
    fun update(favorite: Favorite)

    @Query("SELECT * FROM Favorite")
    fun getAllFavorites(): LiveData<List<Favorite>>

    @Delete
    fun hapusDataFavorit(favorite: Favorite)
}

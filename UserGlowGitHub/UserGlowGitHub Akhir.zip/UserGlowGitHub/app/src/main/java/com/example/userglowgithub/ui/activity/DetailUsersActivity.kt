package com.example.userglowgithub.ui.activity

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.example.userglowgithub.R
import com.example.userglowgithub.databinding.ActivityDetailUsersBinding
import com.example.userglowgithub.ui.adapter.SectionsPagerAdapter
import com.example.userglowgithub.ui.datafavorit.Favorite
import com.example.userglowgithub.ui.response.GitHubUserDetailResponse
import com.example.userglowgithub.ui.viewmodel.DetailViewModel
import com.example.userglowgithub.ui.viewmodel.DetailViewModelFactory
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator


class DetailUsersActivity : AppCompatActivity() {

    companion object {
        val PENGGUNA = "pengguna"
        @StringRes
        private val TAB_TITLES = intArrayOf(
            R.string.followers,
            R.string.following
        )
    }

    private lateinit var binding: ActivityDetailUsersBinding
    private lateinit var detailViewModel: DetailViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pilihan: String = intent.getStringExtra(PENGGUNA)!!
        detailViewModel =
            ViewModelProvider(
                this,DetailViewModelFactory.getInstance(this,pilihan)
            ).get(DetailViewModel::class.java)
        binding = ActivityDetailUsersBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.hide()

        val sectionsPagerAdapter = SectionsPagerAdapter(this)
        val viewPager: ViewPager2 = binding.viewPager
        viewPager.adapter = sectionsPagerAdapter
        val tabs: TabLayout = binding.tabs
        TabLayoutMediator(tabs, viewPager) { tab, position ->
            tab.text = resources.getString(TAB_TITLES[position])
        }.attach()

        val detail = intent.getStringExtra(PENGGUNA).toString()

        detailViewModel.user.observe(this) { DetailUser ->
            mengambilDetailDataUser(DetailUser)
            showLoading(false)
        }
        detailViewModel.mengambilDetailDataUser(detail)

        val fabFavorite: FloatingActionButton = binding.fabFavorite
        fabFavorite.setOnClickListener {
            val username = detailViewModel.user.value?.login
            val avatarUrl = detailViewModel.user.value?.avatarUrl
            if (username != null) {
                detailViewModel.addToFavorites(username,avatarUrl)
                detailViewModel.deleteFavorite(favorite = Favorite())
            }

            if (username != null && avatarUrl != null) {
            }
        }
    }

    @SuppressLint("SetTextI18n")
    private fun mengambilDetailDataUser(detail: GitHubUserDetailResponse) {
        Glide.with(this).load(detail.avatarUrl).into(binding.foto)
        binding.tvUser.text = detail.name
        binding.tvUsername.text = detail.login
        binding.tvFollowers.text = detail.followers.toString() + " Followers"
        binding.tvFollowing.text = detail.following.toString() + " Following"
    }

    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            binding.progressBar2.visibility = View.VISIBLE
        } else {
            binding.progressBar2.visibility = View.GONE
        }
    }
}

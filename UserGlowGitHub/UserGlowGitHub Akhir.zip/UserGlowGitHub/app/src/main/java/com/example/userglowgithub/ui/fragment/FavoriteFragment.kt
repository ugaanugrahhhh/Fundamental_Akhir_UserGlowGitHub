package com.example.userglowgithub.ui.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.userglowgithub.databinding.FragmentFavoriteBinding
import com.example.userglowgithub.ui.adapter.FavoriteAdapter // Perbaikan impor disini
import com.example.userglowgithub.ui.viewmodel.FavoriteViewModel

class FavoriteFragment : Fragment() {

    private lateinit var binding: FragmentFavoriteBinding
    private lateinit var favoriteViewModel: FavoriteViewModel
    private lateinit var adapter: FavoriteAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentFavoriteBinding.inflate(inflater, container, false)
        binding.recyclerViewFavorite.layoutManager = LinearLayoutManager(requireActivity())
        favoriteViewModel = ViewModelProvider(
            requireActivity(),
        ).get(FavoriteViewModel::class.java)
        adapter = FavoriteAdapter { /* Handle item click here */ }
        binding.recyclerViewFavorite.adapter = adapter
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Observe the favorite list from the ViewModel and update the adapter
        favoriteViewModel.getFavoriteUser().observe(viewLifecycleOwner) { favoriteUsers ->
            adapter.submitList(favoriteUsers)
        }
    }
}

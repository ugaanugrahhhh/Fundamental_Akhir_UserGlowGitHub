package com.example.userglowgithub.ui.activity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.userglowgithub.databinding.ActivityFavoritePageBinding
import com.example.userglowgithub.ui.adapter.FavoriteAdapter
import com.example.userglowgithub.ui.adapter.ListUserAdapter
import com.example.userglowgithub.ui.adapter.ListUserAdapter.Companion.PENGGUNA
import com.example.userglowgithub.ui.response.GlowFollowersResponse
import com.example.userglowgithub.ui.viewmodel.DetailViewModelFactory
import com.example.userglowgithub.ui.viewmodel.FavoriteViewModel

class FavoritePageActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFavoritePageBinding
    private lateinit var viewModel: FavoriteViewModel
    private lateinit var adapter: FavoriteAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFavoritePageBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Inisialisasi ViewModel dan Adapter
        viewModel = ViewModelProvider(this,DetailViewModelFactory.getInstance(this,"")
        ).get(FavoriteViewModel::class.java)

        adapter = FavoriteAdapter() { username ->
            // Ketika item di klik, buka halaman Detail User dengan mengirim username sebagai data yang diperlukan
            val intent = Intent(this@FavoritePageActivity, DetailUsersActivity::class.java)
            intent.putExtra(PENGGUNA, username)
            startActivity(intent)
            // Tambahkan kode untuk membuka halaman detail favorit di sini
        }

        // Set adapter ke RecyclerView
        binding.recyclerViewFavorite.adapter = adapter
        val layoutManager = LinearLayoutManager(this)
        binding.recyclerViewFavorite.layoutManager = layoutManager

        // Mengamati perubahan data pengguna favorit dan memperbarui tampilan dengan adapter
        viewModel.getFavoriteUser().observe(this) { favorite ->
            Log.d("TAG SUKA", "onCreate: $favorite")
            adapter.submitList(favorite)
        }


        // Tambahkan onClickListener ke FAB Favorite
        binding.fabFavorite.setOnClickListener {
            // Tambahkan kode untuk membuka halaman Favorite di sini
        }

        supportActionBar?.setDisplayHomeAsUpEnabled(true) // Menampilkan tombol kembali pada ActionBar
        supportActionBar?.title = "Favorite" // Mengatur judul ActionBar sesuai kebutuhan
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                onBackPressed() // Memberikan aksi kembali jika tombol kembali di ActionBar ditekan
                return true
            }
            else -> return super.onOptionsItemSelected(item)
        }
    }
}

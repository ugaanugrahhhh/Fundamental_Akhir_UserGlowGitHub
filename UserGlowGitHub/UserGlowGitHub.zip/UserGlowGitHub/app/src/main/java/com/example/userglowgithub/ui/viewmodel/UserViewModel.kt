package com.example.userglowgithub.ui.viewmodel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.userglowgithub.ui.response.GitHubSearchResponse
import com.example.userglowgithub.ui.response.ItemsItem
import com.example.userglowgithub.ui.retrofit.ApiConfig
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class UserViewModel : ViewModel() {

    private  val _listUser = MutableLiveData<List<ItemsItem>>()
    val listUser : LiveData<List<ItemsItem>> =_listUser

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    init {
        findSearch("Anugrah")
    }

    private fun findSearch(pencarian_pengguna:String) {
//        showLoading(true)
        val client = ApiConfig.getApiService().getGitHubSearch(pencarian_pengguna)
        client.enqueue(object : Callback<GitHubSearchResponse> {
            override fun onResponse(
                call: Call<GitHubSearchResponse>,
                response: Response<GitHubSearchResponse>
            ) {
//                showLoading(false)
                if (response.isSuccessful) {
                    val responseBody = response.body()
                    if (responseBody != null) {

                        Log.d("TAG SUKSES", "Response body: $responseBody")
                    }
                } else {
                    Log.e("TAG", "onFailure: ${response.message()}")
                }
            }
            override fun onFailure(call: Call<GitHubSearchResponse>, t: Throwable) {
//                showLoading(false)
                Log.e("TAG", "onFailure: ${t.message}")
            }
        })
    }
}
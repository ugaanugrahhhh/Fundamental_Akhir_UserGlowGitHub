package com.example.userglowgithub.ui.activity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.View
import android.widget.CompoundButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatDelegate
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.userglowgithub.R
import com.example.userglowgithub.ui.adapter.ListUserAdapter
import com.example.userglowgithub.databinding.ActivityMainBinding
import com.example.userglowgithub.ui.response.GitHubSearchResponse
import com.example.userglowgithub.ui.retrofit.ApiConfig
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.switchmaterial.SwitchMaterial
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val switchTheme = findViewById<SwitchMaterial>(R.id.switch_theme)

        switchTheme.setOnCheckedChangeListener { _: CompoundButton?, isChecked: Boolean ->
            if (isChecked) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                switchTheme.isChecked = true
            } else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                switchTheme.isChecked = false
            }
        }
        binding.progressBar3.visibility = View.GONE
        val fabFavorite = findViewById<FloatingActionButton>(R.id.fabFavorite)
        fabFavorite.setOnClickListener {
            val intent = Intent(this, FavoritePageActivity::class.java)
            startActivity(intent)
        }

        val layoutManager = LinearLayoutManager(this)
        binding.RvUser.layoutManager = layoutManager
        val itemDecoration = DividerItemDecoration(this, layoutManager.orientation)
        binding.RvUser.addItemDecoration(itemDecoration)

        val adapter = ListUserAdapter { username ->
            val intent = Intent(this@MainActivity, DetailUsersActivity::class.java)
            intent.putExtra(DetailUsersActivity.PENGGUNA, username)
            startActivity(intent)
        }

        binding.RvUser.adapter = adapter

        with(binding) {
            searchView.setupWithSearchBar(searchBar)
            searchView
                .editText
                .setOnEditorActionListener { textView, actionId, event ->
                    searchBar.text = searchView.text
                    searchView.hide()
                    Toast.makeText(this@MainActivity, searchView.text, Toast.LENGTH_SHORT).show()

                    findSearch(searchView.text.toString())

                    false
                }
        }
    }
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }


    private fun findSearch(pencarian_pengguna:String) {
        val client = ApiConfig.getApiService().getGitHubSearch(pencarian_pengguna)
        binding.progressBar3.visibility = View.VISIBLE
        client.enqueue(object : Callback<GitHubSearchResponse> {
            override fun onResponse(
                call: Call<GitHubSearchResponse>,
                response: Response<GitHubSearchResponse>
            ) {
                if (response.isSuccessful) {
                    val responseBody = response.body()
                    if (responseBody != null) {
                        val accounts = responseBody.items
                        val adapter = binding.RvUser.adapter as ListUserAdapter
                        adapter.submitList(accounts)


                        binding.progressBar3.visibility = View.GONE

                        Log.d("TAG SUKSES", "Response body: $responseBody")
                    }
                } else {
                    binding.progressBar3.visibility = View.GONE
                    Log.e("TAG", "onFailure: ${response.message()}")
                }
            }
            override fun onFailure(call: Call<GitHubSearchResponse>, t: Throwable) {
                Log.e("TAG", "onFailure: ${t.message}")
                binding.progressBar3.visibility = View.GONE
            }
        })
    }
}

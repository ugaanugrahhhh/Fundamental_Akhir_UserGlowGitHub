package com.example.userglowgithub.ui.fragment

import android.content.ContentResolver
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.userglowgithub.R
import com.example.userglowgithub.databinding.FragmentFollowBinding
import com.example.userglowgithub.ui.adapter.FollowAdapter
import com.example.userglowgithub.ui.adapter.ListUserAdapter
import com.example.userglowgithub.ui.viewmodel.DetailViewModel
import com.example.userglowgithub.ui.viewmodel.DetailViewModelFactory

class FollowFragment : Fragment() {

    private lateinit var binding : FragmentFollowBinding
    private lateinit var detailViewModel : DetailViewModel
    private lateinit var adapter: FollowAdapter
    private var isLoading = false

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding= FragmentFollowBinding.inflate(inflater,container,false)
        binding.recyclerViewFollowing.layoutManager=LinearLayoutManager(requireActivity())
        detailViewModel = ViewModelProvider(requireActivity() ).get(DetailViewModel::class.java)
        adapter = FollowAdapter {  }
        binding.recyclerViewFollowing.adapter=adapter
        return binding.root
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        arguments?.let {
            val position = it.getInt(ARG_POSITION)
            val username = it.getString(ARG_USERNAME)
            if (position == 1){
                detailViewModel.glowFollowers.observe(requireActivity()){
                    adapter.submitList(it)

                }

            } else {
                detailViewModel.glowFollowing.observe(requireActivity()){
                    adapter.submitList(it)
                }


            }
        }
        fun showLoading(isLoading: Boolean) {
            if (isLoading) {
                binding.progressBarFollower.visibility = View.VISIBLE
            } else {
                binding.progressBarFollower.visibility = View.GONE
            }
        }
    }

    companion object {
        const val ARG_SECTION_NUMBER = "section_number"
        const val ARG_POSITION = "position_number"
        const val ARG_USERNAME = "username"
    }

}